# FPGA-Based Traffic Light Controller

## Project Overview
A Verilog HDL based traffic light controller developed and simulated using AMD Vivado 2024.2.

## Features
- Red, Yellow and Green traffic-light control
- Clock-based control
- Reset input
- Emergency vehicle input
- Verilog testbench
- Behavioral simulation and waveform verification

## Tools
- Verilog HDL
- AMD Vivado 2024.2
- XSim Behavioral Simulation

## Project Files
Place the following files in `Source_Code/`:
- traffic_light_controller.v
- traffic_light_controller_tb.v

The simulation waveform screenshot is available in `Simulation_Results/`.

## Important Note
The supplied waveform screenshot shows the emergency input being tested. Before final FPGA submission, verify that the emergency condition produces the exact priority output required by the project specification (typically RED = 1, YELLOW = 0, GREEN = 0 for immediate stop).
